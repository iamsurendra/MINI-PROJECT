package com.java.hotel.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.java.hotel.dtos.RoomDetails;
import com.java.hotel.services.RoomService;

@RestController
public class RoomController {
	@Autowired
	RoomService roomService;

	@RequestMapping(value = "/allRooms",method = RequestMethod.GET,headers="Accept=application/json")
	public List<RoomDetails> getAllRooms() {
		
		
		return roomService.getAllRooms();
		
	}
	
	@RequestMapping(value = "/room/delete/{id}",headers="Accept=application/json",method = RequestMethod.DELETE)
	public List<RoomDetails> deleteRoom(@PathVariable("id") int id) {
		
		roomService.deleteRoom(id);
		return roomService.getAllRooms();
}
	@RequestMapping(value ="/room/create/",consumes = MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json",method = RequestMethod.POST)
	public List<RoomDetails> createRoomDetails(@RequestBody RoomDetails room) {
		
		roomService.addRoom(room);
		return roomService.getAllRooms();
}
	@RequestMapping(value ="/room/search/{id}",headers="Accept=application/json",method = RequestMethod.GET)
	public RoomDetails searchRoom(@PathVariable("id") String id) {
	
		return roomService.searchRoom(id);
}
	@RequestMapping(value ="/room/update/",consumes = MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json",method = RequestMethod.PUT)
	public List<RoomDetails> updateRoomDetails(@RequestBody RoomDetails room) {
		
		roomService.updateRoomDetails(room);
		return roomService.getAllRooms();
}
}
