package com.java.hotel.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.java.hotel.dtos.BookingDetails;
import com.java.hotel.services.BookingService;

@RestController
public class BookingController {
	@Autowired
	BookingService bookingService;
	
	@RequestMapping(value = "/allbookings",method = RequestMethod.GET,headers="Accept=application/json")
	public List<BookingDetails> getAllBookings() {
		
		
		return bookingService.getAllBookings();
		
	}
	
	@RequestMapping(value = "/booking/delete/{id}",headers="Accept=application/json",method = RequestMethod.DELETE)
	public List<BookingDetails> deleteBooking(@PathVariable("id") int id) {
		
		bookingService.deleteBooking(id);
		return bookingService.getAllBookings();
}
	@RequestMapping(value ="/booking/create/",consumes = MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json",method = RequestMethod.POST)
	public List<BookingDetails> createBookingDetails(@RequestBody BookingDetails book) {
		
		bookingService.addBooking(book);
		return bookingService.getAllBookings();
}
	@RequestMapping(value ="/booking/search/{id}",headers="Accept=application/json",method = RequestMethod.GET)
	public BookingDetails searchBooking(@PathVariable("id") String id) {
	
		return bookingService.searchBooking(id);
}
	@RequestMapping(value ="/booking/update/",consumes = MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json",method = RequestMethod.PUT)
	public List<BookingDetails> updateBookingDetails(@RequestBody BookingDetails book) {
		
		bookingService.updateBookingDetails(book);
		return bookingService.getAllBookings();
}
}
