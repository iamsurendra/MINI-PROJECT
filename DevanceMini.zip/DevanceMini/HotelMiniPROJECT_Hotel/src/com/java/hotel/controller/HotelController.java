package com.java.hotel.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.java.hotel.dtos.HotelDetails;
import com.java.hotel.services.HotelService;

@RestController
public class HotelController {
	@Autowired
	HotelService hotelService;
	
	@RequestMapping(value = "/allhotels",method = RequestMethod.GET,headers="Accept=application/json")
	public List<HotelDetails> getAllHotels() {
		
		
		return hotelService.getAllHotels();
		
	}
	
	@RequestMapping(value = "/hotel/delete/{id}",headers="Accept=application/json",method = RequestMethod.DELETE)
	public List<HotelDetails> deleteHotel(@PathVariable("id") int id) {
		
		hotelService.deleteHotel(id);
		return hotelService.getAllHotels();
}
	@RequestMapping(value ="/hotel/create/",consumes = MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json",method = RequestMethod.POST)
	public List<HotelDetails> createHotelDetails(@RequestBody HotelDetails hotel) {
		
		hotelService.addHotel(hotel);
		return hotelService.getAllHotels();
}
	@RequestMapping(value ="/hotel/search/{id}",headers="Accept=application/json",method = RequestMethod.GET)
	public HotelDetails searchHotel(@PathVariable("id") String id) {
	
		return hotelService.searchHotel(id);
}
	@RequestMapping(value ="/hotel/update/",consumes = MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json",method = RequestMethod.PUT)
	public List<HotelDetails> updateHotelDetails(@RequestBody HotelDetails hotel) {
		
		hotelService.updateHotelDetails(hotel);
		return hotelService.getAllHotels();
}
}
