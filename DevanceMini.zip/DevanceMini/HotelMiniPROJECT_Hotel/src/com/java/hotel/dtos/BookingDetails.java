package com.java.hotel.dtos;

import java.sql.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
@Entity
@Table(name = "Booking")
public class BookingDetails {
	@Id
	@Column(name = "Booking_Id")
	private String bookingId;
	/*@Column(name = "Room_Id")
	private String roomId;*/
	/*@Column(name = "User_Id")
	private String userId;*/
	@Column(name = "Booked_From")
	private Date bookedFrom;
	@Column(name = "Booked_To")
	private Date bookedto;
	@Column(name = "No_Of_Adults")
	private int noOfAdults;
	@Column(name = "No_Of_Children")
	private int noOfChildren ;
	@Column(name = "Amount")
	private int amount;
	
	/*@ManyToOne
	@JoinColumn(name = "Room_Id")
	private RoomDetails room;
	
	@ManyToOne
	@JoinColumn(name = "User_Id")
	private User user;*/
	
	public String getBookingId() {
		return bookingId;
	}
	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}
	
	/*public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}*/
	public Date getBookedFrom() {
		return bookedFrom;
	}
	public void setBookedFrom(Date bookedFrom) {
		this.bookedFrom = bookedFrom;
	}
	public Date getBookedto() {
		return bookedto;
	}
	public void setBookedto(Date bookedto) {
		this.bookedto = bookedto;
	}
	public int getNoOfAdults() {
		return noOfAdults;
	}
	public void setNoOfAdults(int noOfAdults) {
		this.noOfAdults = noOfAdults;
	}
	public int getNoOfChildren() {
		return noOfChildren;
	}
	public void setNoOfChildren(int noOfChildren) {
		this.noOfChildren = noOfChildren;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	
	
	
}
