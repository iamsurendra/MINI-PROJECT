package com.java.hotel.dtos;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;


@Entity
@Table(name = "Room")
public class RoomDetails{
	@Id
	@Column(name = "Room_ID")
	private String roomId;
	/*@Column(name = "Hotel_ID")
	private String hotelId;*/
	@Column(name = "Room_No")
	private String roomN0;
	@Column(name = "Room_Type")
	private String roomType;
	@Column(name = "Per_Night_Rate")
	private int perNightRate;
	@Column(name = "Availability")
	private boolean availability ;
	
	/*@ManyToOne
	@JoinColumn(name = "hotel_Id")
	private HotelDetails hotelDetails;
	
	@OneToMany(mappedBy = "BookingDetails", fetch = FetchType.EAGER)
	private Set<BookingDetails> book;*/
	
	public String getRoomId() {
		return roomId;
	}
	public void setRoomId(String roomId) {
		this.roomId = roomId;
	}
	public String getRoomN0() {
		return roomN0;
	}
	public void setRoomN0(String roomN0) {
		this.roomN0 = roomN0;
	}
	public String getRoomType() {
		return roomType;
	}
	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}
	public int getPerNightRate() {
		return perNightRate;
	}
	public void setPerNightRate(int perNightRate) {
		this.perNightRate = perNightRate;
	}
	public boolean isAvailability() {
		return availability;
	}
	public void setAvailability(boolean availability) {
		this.availability = availability;
	}

}
