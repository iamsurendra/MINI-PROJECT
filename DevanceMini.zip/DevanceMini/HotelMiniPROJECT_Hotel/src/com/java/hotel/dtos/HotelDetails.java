package com.java.hotel.dtos;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Hotel")
public class HotelDetails {
	@Id
	@Column(name = "Hotel_ID")
	private String hotelId;
	@Column(name = "Hotel_Name")
	private String hotelName;
	@Column(name = "City")
	private String city;
	@Column(name = "Address")
	private String address;
	@Column(name = "Description")
	private String description ;
	@Column(name = "Avg_Rate_Per_Night")
	private String avgRatePerNight;
	@Column(name = "Phone")
	private String phone;
	@Column(name = "Rating")
	private String rating;
	@Column(name = "Email")
	private String email;
	@Column(name = "Fax")
	private String fax;
/*	
	@OneToMany(mappedBy = "RoomDetails", fetch = FetchType.EAGER)
	private Set<RoomDetails> room;*/
	
	public HotelDetails(String hotelId, String hotelName, String city, String address, String description,
			String avgRatePerNight, String phone, String rating, String email, String fax) {
		super();
		this.hotelId = hotelId;
		this.hotelName = hotelName;
		this.city = city;
		this.address = address;
		this.description = description;
		this.avgRatePerNight = avgRatePerNight;
		this.phone = phone;
		this.rating = rating;
		this.email = email;
		this.fax = fax;
	}
	
	public HotelDetails() {
		super();
	}

	public String getHotelId() {
		return hotelId;
	}
	public void setHotelId(String hotelId) {
		this.hotelId = hotelId;
	}
	public String getHotelName() {
		return hotelName;
	}
	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getAvgRatePerNight() {
		return avgRatePerNight;
	}
	public void setAvgRatePerNight(String avgRatePerNight) {
		this.avgRatePerNight = avgRatePerNight;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getFax() {
		return fax;
	}
	public void setFax(String fax) {
		this.fax = fax;
	}
	@Override
	public String toString() {
		return "HotelDetails [hotelId=" + hotelId + ", hotelName=" + hotelName + ", city=" + city + ", address="
				+ address + ", description=" + description + ", avgRatePerNight=" + avgRatePerNight + ", phone=" + phone
				+ ", rating=" + rating + ", email=" + email + ", fax=" + fax + "]";
	}

	
	
}
