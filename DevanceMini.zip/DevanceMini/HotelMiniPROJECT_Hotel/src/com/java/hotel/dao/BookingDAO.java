package com.java.hotel.dao;

import java.util.List;

import com.java.hotel.dtos.BookingDetails;


public interface BookingDAO {
	public List<BookingDetails> getAllBookings();
	public void addBooking(BookingDetails book);
	public void deleteBooking(int id);
	public BookingDetails searchBooking(String id);
	public void updateBookingDetails(BookingDetails book);
}
