package com.java.hotel.dao;

import java.util.List;

import com.java.hotel.dtos.HotelDetails;


public interface HotelDAO {
	public List<HotelDetails> getAllHotels();
	public void addHotel(HotelDetails hotel);
	public void deleteHotel(int id);
	public HotelDetails searchHotel(String id);
	public void updateHotelDetails(HotelDetails hotel);
}
