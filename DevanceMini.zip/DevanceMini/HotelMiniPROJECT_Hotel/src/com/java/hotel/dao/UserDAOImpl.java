package com.java.hotel.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.java.hotel.Exception.LoginException;
import com.java.hotel.dtos.User;



@Repository
@Transactional
public class UserDAOImpl implements UserDAO{
	@PersistenceContext
	EntityManager entitymanager;


	@Override
	public void adduser(User login) {

		entitymanager.persist(login);
		entitymanager.flush();
	}
	@Override
	public User getUser(String uname) {

		CriteriaBuilder builder = entitymanager.getCriteriaBuilder();
		CriteriaQuery<User> cQuery = builder.createQuery(User.class);
		Root<User> user = cQuery.from(User.class);
		cQuery.select(user).where(builder.or(builder.equal(user.get("userName"), uname)));
		List<User> userList = entitymanager.createQuery(cQuery).getResultList();
		if (null != userList && !userList.isEmpty()) {
			return userList.get(0);
		} else {
			return null;
		}
	}
	@Override
	public User authenticate(User login) throws LoginException {
		/*	String userId = login.getUserId();
		System.out.println(userId);*/
		String queryTwo="select user from User user where user.userName=:uname";
		TypedQuery<User> query=entitymanager.createQuery(queryTwo,User.class);
		query.setParameter("uname",login.getUserName());

		User founduser = query.getSingleResult();
		if(founduser != null)
		{
			return founduser;
		}

		else
			throw new LoginException("Invalid Username!");
	}
	@Override
	public List<User> getAllUsers() {

		Query queryOne=entitymanager.createQuery("FROM User");
		List<User> list=queryOne.getResultList();		
		return list;

	}
}
