package com.java.hotel.dao;

import java.util.List;

import com.java.hotel.dtos.RoomDetails;

public interface RoomDAO {
	public List<RoomDetails> getAllRooms();
	public void addRoom(RoomDetails room);
	public void deleteRoom(int id);
	public RoomDetails searchRoom(String id);
	public void updateRoomDetails(RoomDetails room);
}
