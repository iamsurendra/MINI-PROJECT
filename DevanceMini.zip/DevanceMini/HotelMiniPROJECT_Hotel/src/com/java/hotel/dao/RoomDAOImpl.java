package com.java.hotel.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.java.hotel.dtos.HotelDetails;
import com.java.hotel.dtos.RoomDetails;

@Repository
@Transactional
public class RoomDAOImpl implements RoomDAO{
	@PersistenceContext
	EntityManager entitymanager;
	public List<RoomDetails> getAllRooms() {

		Query queryOne=entitymanager.createQuery("FROM RoomDetails");
		List<RoomDetails> allProduct=queryOne.getResultList();		
		return allProduct;
	}

	@Override
	public void deleteRoom(int id) {

		Query queryTwo=entitymanager.createQuery("DELETE FROM RoomDetails WHERE roomId=:roomid");
		queryTwo.setParameter("roomid",id);
		queryTwo.executeUpdate();


	}

	@Override
	public void addRoom(RoomDetails hotel) {

		entitymanager.persist(hotel);
		entitymanager.flush();

	}

	@Override
	public RoomDetails searchRoom(String id) {

		RoomDetails room=new RoomDetails();
		Query queryOne=entitymanager.createQuery("FROM RoomDetails");
		List<RoomDetails> allRooms=queryOne.getResultList();	

		for (RoomDetails roomobj : allRooms) {
			if(roomobj.getRoomId()==id) {
				room=roomobj;
				break;
			}
		}
		return room;
	}

	@Override
	public void updateRoomDetails(RoomDetails room) {

		Query queryThree=entitymanager.createQuery("UPDATE RoomDetails SET roomN0=:roomN0,roomType=:roomType,perNightRate:perNightRate,avgRatePerNight:avgRatePerNight,"
				+ "availability:availability WHERE roomId=:roomId");
		//queryThree.setParameter("hotelId",room.getHotelId());
		queryThree.setParameter("roomN0",room.getRoomN0());
		queryThree.setParameter("roomType",room.getRoomType());
		queryThree.setParameter("perNightRate",room.getPerNightRate());
		queryThree.setParameter("avgRatePerNight",room.getPerNightRate());
		queryThree.setParameter("availability",room.isAvailability());
		
		queryThree.executeUpdate();
	}
}
