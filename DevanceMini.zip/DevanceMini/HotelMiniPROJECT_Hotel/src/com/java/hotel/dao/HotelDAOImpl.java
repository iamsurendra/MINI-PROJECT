package com.java.hotel.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.java.hotel.dtos.HotelDetails;

@Repository
@Transactional
public class HotelDAOImpl implements HotelDAO{
	@PersistenceContext
	EntityManager entitymanager;
	public List<HotelDetails> getAllHotels() {
		
		Query queryOne=entitymanager.createQuery("FROM HotelDetails");
        List<HotelDetails> allProduct=queryOne.getResultList();		
		return allProduct;
	}

	@Override
	public void deleteHotel(int id) {
		
		Query queryTwo=entitymanager.createQuery("DELETE FROM HotelDetails WHERE hotelId=:hotelid");
		queryTwo.setParameter("hotelid",id);
		queryTwo.executeUpdate();
		
		
	}

	@Override
	public void addHotel(HotelDetails hotel) {
		
		entitymanager.persist(hotel);
		entitymanager.flush();
		
	}

	@Override
	public HotelDetails searchHotel(String id) {
		
		HotelDetails hotel=new HotelDetails();
		Query queryOne=entitymanager.createQuery("FROM HotelDetails");
        List<HotelDetails> allhotels=queryOne.getResultList();	
		
		for (HotelDetails hotelobj : allhotels) {
			if(hotelobj.getHotelId()==id) {
				hotel=hotelobj;
				break;
			}
		}
		return hotel;
	}

	@Override
	public void updateHotelDetails(HotelDetails hotel) {
		
		Query queryThree=entitymanager.createQuery("UPDATE HotelDetails SET hotelName=:hname,"
				+ "city=:city,address=:address,description:description,avgRatePerNight:avgRatePerNight,"
				+ "phone:phone,rating:rating,email:email,fax:fax WHERE hotelId=:hotelId");
		queryThree.setParameter("hname",hotel.getHotelName());
		queryThree.setParameter("city",hotel.getCity());
		queryThree.setParameter("address",hotel.getAddress());
		queryThree.setParameter("description",hotel.getDescription());
		queryThree.setParameter("avgRatePerNight",hotel.getAvgRatePerNight());
		queryThree.setParameter("phone",hotel.getPhone());
		queryThree.setParameter("rating",hotel.getRating());
		queryThree.setParameter("email",hotel.getEmail());
		queryThree.setParameter("fax",hotel.getFax());
		queryThree.executeUpdate();
	}
}
