package com.java.hotel.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.java.hotel.dtos.BookingDetails;
@Repository
@Transactional
public class BookingDAOImpl implements BookingDAO {
	@PersistenceContext
	EntityManager entitymanager;
	public List<BookingDetails> getAllBookings() {

		Query queryOne=entitymanager.createQuery("FROM BookingDetails");
		List<BookingDetails> allProduct=queryOne.getResultList();		
		return allProduct;
	}

	@Override
	public void deleteBooking(int id) {

		Query queryTwo=entitymanager.createQuery("DELETE FROM BookingDetails WHERE bookingId=:bookingId");
		queryTwo.setParameter("bookingId",id);
		queryTwo.executeUpdate();


	}

	@Override
	public void addBooking(BookingDetails book) {

		entitymanager.persist(book);
		entitymanager.flush();

	}

	@Override
	public BookingDetails searchBooking(String id) {

		BookingDetails book=new BookingDetails();
		Query queryOne=entitymanager.createQuery("FROM BookingDetails");
		List<BookingDetails> allbookings=queryOne.getResultList();	

		for (BookingDetails bookobj : allbookings) {
			if(bookobj.getBookingId()==id) {
				book=bookobj;
				break;
			}
		}
		return book;
	}

	@Override
	public void updateBookingDetails(BookingDetails book) {

		Query queryThree=entitymanager.createQuery("UPDATE BookingDetails SET bookedFrom=:bookedFrom,bookedto:bookedto,noOfAdults:noOfAdults,"
				+ "noOfChildren:noOfChildren,amount:amount WHERE roomId=:roomId");
	/*	queryThree.setParameter("roomId",book.getRoomId());
		queryThree.setParameter("userId",book.getUserId());*/
		queryThree.setParameter("bookedFrom",book.getBookedFrom());
		queryThree.setParameter("bookedto",book.getBookedto());
		queryThree.setParameter("noOfAdults",book.getNoOfAdults());
		queryThree.setParameter("noOfChildren",book.getNoOfChildren());
		queryThree.setParameter("amount",book.getAmount());
		
		queryThree.executeUpdate();
	}
	
}
