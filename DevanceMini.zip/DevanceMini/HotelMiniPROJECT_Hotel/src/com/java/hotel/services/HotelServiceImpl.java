package com.java.hotel.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.java.hotel.dao.HotelDAO;
import com.java.hotel.dtos.HotelDetails;


@Service
@Transactional
public class HotelServiceImpl  implements HotelService{
	@Autowired
	HotelDAO hotelDAO;

	@Override
	public List<HotelDetails> getAllHotels() {
		
		return hotelDAO.getAllHotels();
	}

	@Override
	public void addHotel(HotelDetails hotel) {
		hotelDAO.addHotel(hotel);
		
	}

	@Override
	public void deleteHotel(int id) {
		
		hotelDAO.deleteHotel(id);
	}

	@Override
	public HotelDetails searchHotel(String id) {
		
		return hotelDAO.searchHotel(id);
	}

	@Override
	public void updateHotelDetails(HotelDetails hotel) {
		
		hotelDAO.updateHotelDetails(hotel);
	}
}
