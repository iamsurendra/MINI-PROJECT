package com.java.hotel.services;

import java.util.List;

import com.java.hotel.Exception.LoginException;
import com.java.hotel.dtos.User;

public interface UserService {

	public void adduser(User login);
	public User authenticate(User login) throws LoginException;
	public List<User> getAllUsers();


	
}
