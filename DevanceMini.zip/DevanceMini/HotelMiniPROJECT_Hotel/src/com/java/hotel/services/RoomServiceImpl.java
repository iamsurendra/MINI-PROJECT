package com.java.hotel.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.java.hotel.dao.RoomDAO;
import com.java.hotel.dtos.RoomDetails;

@Service
@Transactional
public class RoomServiceImpl implements RoomService{
	@Autowired
	RoomDAO roomDao;
	

	@Override
	public void addRoom(RoomDetails room) {
		
		roomDao.addRoom(room);
	}
	@Override
	public List<RoomDetails> getAllRooms() {
		
		return roomDao.getAllRooms();
	}

	
	@Override
	public void deleteRoom(int id) {
		
		roomDao.deleteRoom(id);
	}

	@Override
	public RoomDetails searchRoom(String id) {
		
		return roomDao.searchRoom(id);
	}

	@Override
	public void updateRoomDetails(RoomDetails room) {
		
		roomDao.updateRoomDetails(room);
	}


	
}
