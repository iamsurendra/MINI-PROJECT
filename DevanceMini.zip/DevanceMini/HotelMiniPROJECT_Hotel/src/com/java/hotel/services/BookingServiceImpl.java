package com.java.hotel.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.java.hotel.dao.BookingDAO;
import com.java.hotel.dtos.BookingDetails;
@Service
@Transactional
public class BookingServiceImpl implements BookingService {
	@Autowired
	BookingDAO bookingDAO;

	@Override
	public List<BookingDetails> getAllBookings() {
		
		return bookingDAO.getAllBookings();
	}

	@Override
	public void addBooking(BookingDetails book) {
		
		bookingDAO.addBooking(book);
	}

	@Override
	public void deleteBooking(int id) {
		bookingDAO.deleteBooking(id);
		
	}

	@Override
	public BookingDetails searchBooking(String id) {
		
		return bookingDAO.searchBooking(id);
	}

	@Override
	public void updateBookingDetails(BookingDetails book) {
		
		bookingDAO.updateBookingDetails(book);
	}
	
}
