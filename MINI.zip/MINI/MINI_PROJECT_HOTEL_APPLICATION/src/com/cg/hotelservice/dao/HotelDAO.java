package com.cg.hotelservice.dao;

import java.util.ArrayList;
import com.cg.hotelservice.dto.AdminRegister;
import com.cg.hotelservice.dto.UserRegister;
import com.cg.hotelservice.exception.HotelException;






public interface HotelDAO {

	int addAdmin(AdminRegister emp)throws HotelException;
	AdminRegister getAdminById(int adminId)throws HotelException;
	int addUser(UserRegister emp)throws HotelException;
	UserRegister getUserById(int accountnumber)throws HotelException;
	ArrayList<AdminRegister>getAllAdmin()throws HotelException;
	ArrayList<UserRegister>getAllUser()throws HotelException;
	UserRegister removeUser(int empId)throws HotelException;
	AdminRegister removeAdmin(int empId) throws HotelException;

}







