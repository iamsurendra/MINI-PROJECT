package com.team.application.repositories.display;

import java.util.List;

public interface DisplayRepository {
	
	public List<Object[]> getCities();
	
	public List<Object> getHotelChainNames();
}
