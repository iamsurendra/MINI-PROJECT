package com.java.hotel.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.java.hotel.dtos.HotelDetails;

@Repository
public class HotelDAOImpl implements HotelDAO{
	@PersistenceContext
	EntityManager entitymanager;
	public List<HotelDetails> getAllHotels() {
		
		Query queryOne=entitymanager.createQuery("FROM HotelDetails");
        List<HotelDetails> allProduct=queryOne.getResultList();		
		return allProduct;
	}

	@Override
	public void deleteHotel(int id) {
		
		Query queryTwo=entitymanager.createQuery("DELETE FROM HotelDetails WHERE hotelId=:hotelid");
		queryTwo.setParameter("hotelid",id);
		queryTwo.executeUpdate();
		
		
	}

	@Override
	public void addHotel(HotelDetails hotel) {
		
		entitymanager.persist(hotel);
		entitymanager.flush();
		
	}

	@Override
	public HotelDetails searchHotel(String id) {
		
		HotelDetails hotel=new HotelDetails();
		Query queryOne=entitymanager.createQuery("FROM HotelDetails");
        List<HotelDetails> allhotels=queryOne.getResultList();	
		
		for (HotelDetails hotelobj : allhotels) {
			if(hotelobj.getHotelId()==id) {
				hotel=hotelobj;
				break;
			}
		}
		return hotel;
	}

	@Override
	public void updateHotelDetails(HotelDetails hotel) {
		
		Query queryThree=entitymanager.createQuery("UPDATE HotelDetails SET hotelName=:hname,empSalary=:esal,empDepartment=:empDep WHERE empId=:eid");
		queryThree.setParameter("ename",hotel.getHotelName());
		queryThree.setParameter("esal",hotel.getEmpSalary());
		queryThree.setParameter("empDep",hotel.getEmpDepartment());
		queryThree.setParameter("eid",hotel.getEmpId());
		queryThree.executeUpdate();
	}
}
