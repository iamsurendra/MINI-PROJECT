package com.java.hotel.dao;

import org.springframework.stereotype.Repository;

@Repository
public class RoomDAOImpl implements RoomDAO{

}
