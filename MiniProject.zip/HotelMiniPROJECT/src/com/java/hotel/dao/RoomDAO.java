package com.java.hotel.dao;

public interface RoomDAO {

}
