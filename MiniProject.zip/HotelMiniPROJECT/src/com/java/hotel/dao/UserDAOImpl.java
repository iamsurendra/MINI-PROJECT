package com.java.hotel.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.springframework.stereotype.Repository;
import com.java.hotel.Exception.LoginException;
import com.java.hotel.dtos.User;


@Repository
public class UserDAOImpl implements UserDAO{
	@PersistenceContext
	EntityManager entitymanager;
	

	@Override
	public void adduser(User login) {
		
		entitymanager.persist(login);
	}

	@Override
	public User authenticate(User login) throws LoginException {
		String userName = login.getUserName();
		
		User founduser = entitymanager.find(User.class, userName);
		if(founduser != null)
		{
			return founduser;
		}
		
		else
			throw new LoginException("Invalid Username!");
	}
	@Override
	public List<User> getAllUsers() {
		
		Query queryOne=entitymanager.createQuery("FROM User");
        List<User> list=queryOne.getResultList();		
		return list;

}}
