package com.java.hotel.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.java.hotel.dtos.HotelDetails;
@Repository
public class BookingDAOImpl implements BookingDAO {

	
}
