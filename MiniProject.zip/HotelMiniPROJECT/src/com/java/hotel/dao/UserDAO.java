package com.java.hotel.dao;

import java.util.List;

import com.java.hotel.Exception.LoginException;
import com.java.hotel.dtos.User;

public interface UserDAO  {
 
	public void adduser(User login);
	public User authenticate(User login) throws LoginException;
	public List<User> getAllUsers();

}
