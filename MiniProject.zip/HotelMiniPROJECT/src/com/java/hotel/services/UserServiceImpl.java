package com.java.hotel.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.java.hotel.Exception.LoginException;
import com.java.hotel.dao.UserDAO;
import com.java.hotel.dtos.User;

@Service("userService")
public class UserServiceImpl implements UserService {

	@Autowired
	UserDAO userDAO;

	@Override
	public void adduser(User login) {
		
		userDAO.adduser(login);
	}

	@Override
	public User authenticate(User login) throws LoginException {

		return userDAO.authenticate(login);
	}

	@Override
	public List<User> getAllUsers() {
		
		return userDAO.getAllUsers();
	}




	
}
