package com.java.hotel.services;

public interface RoomService {

}
