package com.java.hotel.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.java.hotel.dao.HotelDAO;


@Service
public class HotelServiceImpl  implements HotelService{
	/*@Autowired
	HotelDAO hotelDAO;*/
}
