package com.java.hotel.services;

import org.springframework.beans.factory.annotation.Autowired;

import com.java.hotel.dao.BookingDAO;

public class BookingServiceImpl implements BookingService {
	/*@Autowired
	BookingDAO bookingDAO;*/
}
 