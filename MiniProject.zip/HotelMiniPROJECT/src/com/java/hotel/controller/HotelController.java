/*package com.java.hotel.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import com.java.hotel.services.HotelService;

@RestController
public class HotelController {
	@Autowired
	HotelService hotelService;
}
*/