/*package com.java.hotel.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import com.java.hotel.services.RoomService;

@RestController
public class RoomController {
	@Autowired
	RoomService roomService;
}
*/