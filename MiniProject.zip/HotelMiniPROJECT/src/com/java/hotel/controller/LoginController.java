package com.java.hotel.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.springwithangular.beans.Employee;
import com.java.hotel.Exception.LoginException;
import com.java.hotel.dtos.User;
import com.java.hotel.services.UserService;

//@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class LoginController {
	@Autowired
	UserService userService;


	//@PostMapping(value = "/addUser", consumes = "application/json")
	
	@RequestMapping(value ="/user/addUser/",consumes = MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json",method = RequestMethod.POST)
	public String adduser(@RequestBody User login) {

		userService.adduser(login);
		return "User added Success Fully";
	}
	@RequestMapping(value ="/user/getlogin/",consumes = MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json",method = RequestMethod.POST)
	public String authenticate(@RequestBody User login) throws LoginException {
		User log = userService.authenticate(login);
		String pass = log.getPassword();

		if (pass.equals(login.getPassword()))
			return "Login Successfull";
		else 
			throw new LoginException("Invalid Password!") ;

	}
	@RequestMapping(value = "/userslist",method = RequestMethod.GET,headers="Accept=application/json")
	public List<User> getAllUsers() {
		
		return userService.getAllUsers();
		
	}


}