package com.capgemini.dao;

import java.util.List;

import com.capgemini.entity.DefectList;
import com.capgemini.entity.Department;
import com.capgemini.entity.Login;
import com.capgemini.entity.PartList;
import com.capgemini.entity.Technician;
import com.capgemini.exception.LoginException;
import com.capgemini.exception.PartsDefectException;

public interface PartsDefectTrackerDao {
	
	public void adduser(Login login);
	
	public Login authenticate(Login login) throws LoginException;
	
	
	
	List<PartList> getPartList() throws PartsDefectException;
	
	int validatePartNumber(String itemNumber)throws PartsDefectException;

	int createDefect()throws PartsDefectException;
	
	int getDepartmentId(String dptName)throws PartsDefectException;
	
	List<String> getTechnicianName(String dptName)throws PartsDefectException;

	List<Department> getDepartmentNames()throws PartsDefectException;
	
	int addDefect(DefectList defect) throws PartsDefectException;
	
	
}
