package com.capgemini.dao;

import com.capgemini.entity.PartList;

public interface PartListDAO {
	
	void createPart(PartList pl);

}
