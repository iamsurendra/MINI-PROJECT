package com.capgemini.exception;

public class PartsDefectException extends Exception{

	public PartsDefectException() {
		super();
	}

	public PartsDefectException(String message) {
		super(message);
	}
	
	

}
