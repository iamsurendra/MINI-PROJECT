package com.capgemini.service;

import com.capgemini.entity.Department;

public interface DepartmentService {

	void addDepartment(Department dpt);

	void updateDepartment(Department dpt);

	void deleteDepartment(int dptId);
}
