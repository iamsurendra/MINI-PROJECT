package com.capgemini.dao;

import com.capgemini.entity.Technician;

public interface TechnicianDao {

	void addTechnician(Technician tech);

	void updateTechnician(Technician tech);

	void deleteTechnician(int techId);

}
