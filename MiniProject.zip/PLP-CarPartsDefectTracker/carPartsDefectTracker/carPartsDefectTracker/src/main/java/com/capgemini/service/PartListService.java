package com.capgemini.service;


import com.capgemini.entity.PartList;

public interface PartListService {

	void createPart(PartList pl);
}
