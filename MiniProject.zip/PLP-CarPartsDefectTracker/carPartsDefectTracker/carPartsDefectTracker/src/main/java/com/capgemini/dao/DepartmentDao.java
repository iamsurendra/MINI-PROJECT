package com.capgemini.dao;

import com.capgemini.entity.Department;

public interface DepartmentDao {

	void addDepartment(Department dpt);
	
	void updateDepartment(Department dpt);
	
	void deleteDepartment(int dptId);
}
