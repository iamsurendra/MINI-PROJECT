package com.capgemini.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.dao.PartsDefectTrackerDao;
import com.capgemini.entity.DefectList;
import com.capgemini.entity.Department;
import com.capgemini.entity.Login;
import com.capgemini.entity.PartList;
import com.capgemini.entity.Technician;
import com.capgemini.exception.LoginException;
import com.capgemini.exception.PartsDefectException;

@Service
@Transactional
public class PartsDefectTrackerServiceImpl implements PartsDefectTrackerService {
	
	@Autowired
	PartsDefectTrackerDao dao;
	
	
	@Override
	public void adduser(Login login) {
		dao.adduser(login);
		
	}


	@Override
	public Login authenticate(Login login) throws LoginException {
		return dao.authenticate(login);
	}
	
	

	@Override
	public List<PartList> getPartList() throws PartsDefectException{

		
		return dao.getPartList();
	}


	@Override
	public int validatePartNumber(String itemNumber) throws PartsDefectException{
		// TODO Auto-generated method stub
		return dao.validatePartNumber(itemNumber);
	}


	@Override
	public int createDefect() throws PartsDefectException{
		// TODO Auto-generated method stub
		 return dao.createDefect();

	}


	@Override
	public int getDepartmentId(String dptName) throws PartsDefectException{
		// TODO Auto-generated method stub
		return dao.getDepartmentId(dptName);
	}


	@Override
	public List<String> getTechnicianName(String dptName)throws PartsDefectException {
		// TODO Auto-generated method stub
		return dao.getTechnicianName(dptName);
	}


	@Override
	public List<Department> getDepartmentNames()throws PartsDefectException {
		// TODO Auto-generated method stub
		return dao.getDepartmentNames();
	}


	@Override
	public int addDefect(DefectList defect) throws PartsDefectException {
		return dao.addDefect(defect);
	}



	
	
	


}
