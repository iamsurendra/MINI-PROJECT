package com.capgemini.service;

import com.capgemini.entity.Technician;

public interface TechnicianService {

	void addTechnician(Technician tech);

	void updateTechnician(Technician tech);

	void deleteTechnician(int techId);
}
