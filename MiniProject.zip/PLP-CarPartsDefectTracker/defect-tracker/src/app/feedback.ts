export class Feedback {
    feedback:any;
}