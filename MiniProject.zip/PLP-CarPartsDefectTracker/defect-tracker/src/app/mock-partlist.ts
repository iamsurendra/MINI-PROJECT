import { Partlist } from './partlist';

export const PARTLIST:Partlist[]=[

]