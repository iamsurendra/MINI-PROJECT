import { Injectable, Input } from '@angular/core';
import { DefectService } from './defect.service';
import { Observable } from 'rxjs';
import { Login } from '../login';
import { Partlist } from '../partlist';

@Injectable({
  providedIn: 'root'
})
export class AuthserviceService {


  constructor() { 
    
  }
  

  authenticate(username, password) {
    if (username === "priyam123" && password === "123abc") {
     sessionStorage.setItem('username', username)
      return true;
    } else if (username === "mahesh23" && password === "abc23") {
      sessionStorage.setItem('username', username)
      return true;
    }
    else{
      return false;
    }
    }

    authenticatetech(username, password) {
      if (username === "vijay123" && password === "123xyz") {
       sessionStorage.setItem('username', username)
        return true;
      } else if (username === "sahithya" && password === "mno123") {
        sessionStorage.setItem('username', username)
        return true;
      }
      else if (username === "sahithya12" && password === "sah123") {
        sessionStorage.setItem('username', username)
        return true;
      }
      else if (username === "venkatesh51" && password === "venki009") {
        sessionStorage.setItem('username', username)
        return true;
      }
      else if (username === "amit13" && password === "123xyz") {
        sessionStorage.setItem('username', username)
        return true;
      }
      else{
        return false;
      }
      }

      isUserLoggedIn() {
        let user = sessionStorage.getItem('username')
        console.log(!(user === null))
        return !(user === null)
      }
    
      logOut() {
        sessionStorage.removeItem('username')
      }
  }

