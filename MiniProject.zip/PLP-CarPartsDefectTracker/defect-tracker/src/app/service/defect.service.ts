import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Partlist } from '../partlist';
import { Department } from '../department';




@Injectable({
  providedIn: 'root'
})
export class DefectService {

  private baseUrl = 'http://localhost:8087/api'; 

  constructor(private http: HttpClient) { }

  plantNumber;
  partNumber;
  username;
  department:Department[];

  getlogin(username):Observable<String>
  {
    return this.http.get<String>(`${this.baseUrl}`+`/getlogin/${username}`);
  }

  getPartLists(): Observable<any> {
    return this.http.get(`${this.baseUrl}`+`/getPartsList`);
  }
  
  validate(partNumber):Observable<number>{
    return this.http.get<number>(`${this.baseUrl}`+`/validate/${partNumber}`);
  }

  getDepartmentNames():Observable<any> {
    return this.http.get(`${this.baseUrl}`+`/getDptNames`);
}

getTechnicianNames(departmentName):Observable<any>{
  return this.http.get(`${this.baseUrl}`+`/getTechName/${departmentName}`);
}

createDefectNumber():Observable<number> {
  return this.http.get<number>(`${this.baseUrl}`+`/createdefect`);
}

addDefect(defectList : Object):any{
  console.log("defect")
  return this.http.post(`${this.baseUrl}`+`/addDefect`,defectList);
}

getDefectList(): Observable<any> {
  return this.http.get(`${this.baseUrl}`+`/getDefectList`);
}

setNo(plantNumber,partNumber){
  this.partNumber=partNumber;
  this.plantNumber=plantNumber;
}

getPlantNumber():any{
return this.plantNumber;
}

getPartNumber():any{
  return this.partNumber;
}

adddept(department : Department) : Observable<Object>{
  return this.http.post(`${this.baseUrl}` + `/adddept`, department);
}

}
