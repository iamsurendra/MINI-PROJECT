export class DefectList{

defectNumber:number
plantNumber:number
partNumber:string
overAllStatus:string
departmentName:string
technicianName:string
decision:any
}