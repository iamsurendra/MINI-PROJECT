import { Plant } from './plant';

export const PLANTS : Plant [] = [

];