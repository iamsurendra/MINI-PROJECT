export class Department{
  
    departmentId:number
    departmentName:string

    
  }