import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DefectfeedbackComponent } from './defectfeedback.component';

describe('DefectfeedbackComponent', () => {
  let component: DefectfeedbackComponent;
  let fixture: ComponentFixture<DefectfeedbackComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DefectfeedbackComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DefectfeedbackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
