import { Component, OnInit } from '@angular/core';
import { Plant } from '../plant';
import { DefectService } from '../service/defect.service';
import { AuthserviceService } from '../service/authservice.service';
import { Observable } from 'rxjs';
import { DefectList } from '../DefectList';
import { Router } from '@angular/router';

@Component({
  selector: 'app-defectfeedback',
  templateUrl: './defectfeedback.component.html',
  styleUrls: ['./defectfeedback.component.css']
})
export class DefectfeedbackComponent implements OnInit {
  plant: Plant;

 // defect:DefectList;

  departments:Observable<any>

  techNames:Observable<any>;

  departmentName;

  dftNumber;

  pltNumber;

  prtNumber;

  list:any;

  statuses = ['Active','On Progress','Assigned']

  defect:DefectList =new DefectList();

  constructor(private defectService : DefectService, private auth:AuthserviceService, private router:Router) { 
    this.plant=new Plant(); 
    
  }

 
  ngOnInit() {

    this.departmentNames();
   // this. createDefectNumber();
    this.getPlantNumber();
    this.getpartNumber();


    
    }
  onSubmit() {
    this.defect.partNumber=this.prtNumber;
    this.defect.plantNumber=this.pltNumber;
    console.log("add")
    this.defectService.addDefect(this.defect).subscribe(data=> this.dftNumber=data);
    // this.defectService.addDefect(this.defect).subscribe(data=> console.log(data), error => console.log(error));
    this.defect=new DefectList();
   alert(JSON.stringify("Work Has Assigned to the technician"))

  }
 
    departmentNames() {
      this.defectService.getDepartmentNames().subscribe(data=>this.departments=data);  
    }

    technicianNames() {
      console.log("name")
      this.departmentName= (<HTMLSelectElement>document.getElementById('dpt')).value;
      this.defectService.getTechnicianNames(this.departmentName).subscribe(data=>this.techNames=data);
      console.log(this.techNames)
     }

     

    getpartNumber()
    {
     this.prtNumber=this.defectService.getPartNumber();
    }

    getPlantNumber()
    {
      this.pltNumber=this.defectService.getPlantNumber();
    }

    logout(){
      this.router.navigate(['/logout']);       
    }
}
