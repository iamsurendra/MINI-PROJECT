import { Component, OnInit } from '@angular/core';
import { DefectList } from '../DefectList';
import { DefectService } from '../service/defect.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-defect-list',
  templateUrl: './defect-list.component.html',
  styleUrls: ['./defect-list.component.css']
})
export class DefectListComponent implements OnInit {

  defectlist:Observable<any>;
  constructor(private defservice : DefectService) { }

  ngOnInit() {
    this.defdata();
  }
  defdata() {
    this.defectlist = this.defservice.getDefectList();
  }



}
