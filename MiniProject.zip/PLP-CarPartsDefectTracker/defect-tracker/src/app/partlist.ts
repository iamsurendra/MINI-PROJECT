export class Partlist{
    partNumber: String ;

    partName : String ;

    description : String ;

    plantNumber : number;

    zbIndicator : String ;

    supplierNumber : number ;

    supplierName : String ;

    colourIndicator : String ;

    mrpControllerIndex : String ;

    mrpControllerName : String ;

    modelSeries : String ;

    typeVersion : String ;

}
