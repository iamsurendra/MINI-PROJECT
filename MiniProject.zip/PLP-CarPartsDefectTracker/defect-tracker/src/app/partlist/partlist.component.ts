import { Component, OnInit, Pipe, PipeTransform, Input } from '@angular/core';
import { PARTLIST } from '../mock-partlist';
import { Partlist } from '../partlist';
import { Observable } from 'rxjs';
import { DefectService } from '../service/defect.service';

@Component({
  selector: 'app-partlist',
  templateUrl: './partlist.component.html',
  styleUrls: ['./partlist.component.css']
})

export class PartlistComponent implements OnInit {

  
  partlist:Observable<any>;

  constructor(private defectService : DefectService) { }

  ngOnInit() {
    this.reloadData();
  }
  reloadData() {
    this.partlist = this.defectService.getPartLists();
  }

}
