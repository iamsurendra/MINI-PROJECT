import { Component, OnInit } from '@angular/core';
import { Login } from '../login';
import { Router } from '@angular/router';
import { DefectService } from '../service/defect.service';
import { Observable } from 'rxjs';
import { AuthserviceService } from '../service/authservice.service';

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css'],
  
})
export class HomepageComponent implements OnInit {

   login:Login;


  username = ''
  password = ''



  constructor(private router:Router, private authservice : AuthserviceService) { 
    this.login=new Login();
  }


  ngOnInit() {
  }


  checkLogin() {
    if (this.authservice.authenticate(this.username, this.password)) 
    {
      alert(JSON.stringify("Login Sucessful"))
      this.router.navigate(['/view-component'])
    } 
    else
    {
        alert(JSON.stringify("Wrong Id or Password"))

    }
  }

  checkLoginTech()
  {
    if(this.authservice.authenticatetech(this.username,this.password))
    {
      alert(JSON.stringify("Login Sucessful"))
      this.router.navigate(['/feedbacks'])
    }
    else
    {
      
      alert(JSON.stringify("Wrong Id or Password"))
    }
  }

}
