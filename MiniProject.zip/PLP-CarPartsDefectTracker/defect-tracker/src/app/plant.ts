export class Plant{
    plantnumber:string;
    decision:any;
}