import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms'
import { AngularDualListBoxModule } from 'angular-dual-listbox';
import { Ng2SearchPipeModule } from 'ng2-search-filter';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ViewComponentComponent } from './view-component/view-component.component';
import { HomepageComponent } from './homepage/homepage.component';
import { PartlistComponent } from './partlist/partlist.component';
import { DefectcreationComponent } from './defectcreation/defectcreation.component';
import { DefectfeedbackComponent } from './defectfeedback/defectfeedback.component';
import { FeedbacksComponent } from './feedbacks/feedbacks.component';
import { HttpClientModule } from '@angular/common/http';
import { DefectListComponent } from './defect-list/defect-list.component';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { LogoutComponent } from './logout/logout.component';

@NgModule({
  declarations: [
    AppComponent,
    ViewComponentComponent,
    HomepageComponent,
    PartlistComponent,
    DefectcreationComponent,
    DefectfeedbackComponent,
    FeedbacksComponent,
    DefectListComponent,
    LogoutComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    AngularDualListBoxModule,
    Ng2SearchPipeModule,
    HttpClientModule,
    NgbModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
