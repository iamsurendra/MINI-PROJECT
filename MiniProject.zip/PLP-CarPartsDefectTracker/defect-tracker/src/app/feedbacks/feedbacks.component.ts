import { Component, OnInit } from '@angular/core';
import { Feedback } from '../feedback';
import { Router } from '@angular/router';
import { AuthserviceService } from '../service/authservice.service';

@Component({
  selector: 'app-feedbacks',
  templateUrl: './feedbacks.component.html',
  styleUrls: ['./feedbacks.component.css']
})
export class FeedbacksComponent implements OnInit {

  feed:Feedback;
  constructor(private router:Router, private auth : AuthserviceService) { this.feed=new Feedback();}

  dept = ['Engine','Tyres','Brakes','Electronic','Body']
  
  ngOnInit() {
  }
  onSubmit(){
    alert(JSON.stringify("Mail Has Sent to the User"))
  }
  logout()
  {
    this.router.navigate(['/logout'])
  }
}
