import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BnNgIdleService } from 'bn-ng-idle'
@Component({
  selector: 'app-view-component',
  templateUrl: './view-component.component.html',
  styleUrls: ['./view-component.component.css']
})
export class ViewComponentComponent implements OnInit {

  source = ['PART NUMBER', 'PART NAME', 'PLANT NUMNBER', 'MODEL SERIES'];
  target = [];
  constructor(private bnIdle: BnNgIdleService,private router:Router) {
    this.bnIdle.startWatching(500).subscribe((res) => { if (res) { alert(JSON.stringify("Session Timeout"));

        this.router.navigate(['/logout']);

      }

    })
  }

  ngOnInit() {
  }

}
