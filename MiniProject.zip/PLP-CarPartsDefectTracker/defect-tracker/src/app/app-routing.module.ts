import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomepageComponent } from './homepage/homepage.component';
import { ViewComponentComponent } from './view-component/view-component.component';
import { PartlistComponent } from './partlist/partlist.component';
import { DefectcreationComponent } from './defectcreation/defectcreation.component';
import { DefectfeedbackComponent } from './defectfeedback/defectfeedback.component';
import { FeedbacksComponent } from './feedbacks/feedbacks.component';
import { DefectListComponent } from './defect-list/defect-list.component';
import { AuthGaurdService } from './service/auth-gaurd.service';
import { LogoutComponent } from './logout/logout.component';

const routes: Routes = [

{path : '',redirectTo: '/homepage', pathMatch:'full'},
{path : 'homepage', component: HomepageComponent},
{path : 'view-component', component : ViewComponentComponent,canActivate:[AuthGaurdService] },
{path : 'partlist', component : PartlistComponent,canActivate:[AuthGaurdService] },
{path : 'defectcreation', component : DefectcreationComponent,canActivate:[AuthGaurdService] },
{path : 'defectfeedback', component : DefectfeedbackComponent,canActivate:[AuthGaurdService] },
{path : 'feedbacks', component : FeedbacksComponent,canActivate:[AuthGaurdService] },
{path : 'showdefectlist', component : DefectListComponent,canActivate:[AuthGaurdService]},
{path : 'logout', component : LogoutComponent,canActivate:[AuthGaurdService] }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
