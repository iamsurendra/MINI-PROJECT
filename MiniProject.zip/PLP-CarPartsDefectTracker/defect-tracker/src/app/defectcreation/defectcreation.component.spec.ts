import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DefectcreationComponent } from './defectcreation.component';

describe('DefectcreationComponent', () => {
  let component: DefectcreationComponent;
  let fixture: ComponentFixture<DefectcreationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DefectcreationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DefectcreationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
