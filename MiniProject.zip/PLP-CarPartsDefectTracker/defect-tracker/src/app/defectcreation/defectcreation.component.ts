import { Component, OnInit, Input } from '@angular/core';
import { DefectService } from '../service/defect.service';
import { AuthserviceService } from '../service/authservice.service';
import { Partlist } from '../partlist';
import { Router } from '@angular/router';

@Component({
  selector: 'app-defectcreation',
  templateUrl: './defectcreation.component.html',
  styleUrls: ['./defectcreation.component.css']
})
export class DefectcreationComponent implements OnInit {


  partNumber ;
  part:Partlist[];
  flag:boolean;
  public plantNumber;


  constructor(private defectService : DefectService, private auth:AuthserviceService,private route:Router) { }

  ngOnInit() {
  }
  validate(){
    this.partNumber
  }
  onSubmit() {
   this.partNumber= (<HTMLSelectElement>document.getElementById('partNumber')).value;
   this.defectService.validate(this.partNumber).subscribe(data=>this.plantNumber=data);
  this.validatePlant(this.plantNumber);

  this.defectService.setNo(this.plantNumber,this.partNumber);
  }

  
  
  validatePlant(plantNumber){
    if(plantNumber == null)
    {
      this.flag=false;
      alert("Invalid PartNumber");
    }
    else{
      this.flag=true; 
     }
  }
  onSubmitform(plantNumber){
    if(plantNumber == null)
    {
      alert(" Plant Number is not generated");
    }
    else{
      this.route.navigate(['/defectfeedback']);
     }
    
  }
}
